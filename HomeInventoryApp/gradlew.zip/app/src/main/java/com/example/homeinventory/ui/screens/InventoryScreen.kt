package com.example.homeinventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.homeinventory.viewmodel.SharedInventoryViewModel
import com.example.homeinventory.model.Item

@Composable
fun InventoryScreen(viewModel: SharedInventoryViewModel = viewModel()) {
    val items by viewModel.allItems.collectAsState(initial = emptyList())

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text("Inventory", style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(16.dp))

        if (items.isEmpty()) {
            Text("No items added yet.")
        } else {
            for (item in items) {
                ItemCard(item)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun ItemCard(item: Item) {
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Name: ${item.name}")
            Text("Description: ${item.description}")
            Text("Room: ${item.room}")
        }
    }
}



