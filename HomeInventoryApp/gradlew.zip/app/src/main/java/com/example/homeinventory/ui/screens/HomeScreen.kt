@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.homeinventory.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.homeinventory.R
import com.example.homeinventory.viewmodel.SharedInventoryViewModel
import com.example.homeinventory.routes.Screen

@Composable
fun HomeScreen(
    onAddItemClick: () -> Unit,
    onRoomClick: () -> Unit,
    viewModel: SharedInventoryViewModel,
    navController: NavController = rememberNavController()
) {
    var searchText by remember { mutableStateOf(TextFieldValue("")) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Home Inventory", fontSize = 24.sp, modifier = Modifier.padding(8.dp))

        TextField(
            value = searchText,
            onValueChange = { searchText = it },
            placeholder = { Text("Search items...") },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            shape = RoundedCornerShape(8.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.LightGray,
                unfocusedContainerColor = Color.LightGray,
                disabledContainerColor = Color.Gray
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text("Categories", fontSize = 18.sp, modifier = Modifier.padding(8.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            CategoryItem("Tools")
            CategoryItem("Kitchen")
            CategoryItem("Documents")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Recent Items", fontSize = 18.sp, modifier = Modifier.padding(8.dp))
        Column {
            ItemRow("Hammer", R.drawable.hammer)
            ItemRow("Recipe Book", R.drawable.recipe_book)
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = onAddItemClick,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) {
            Text("Add Item")
        }

        Button(
            onClick = onRoomClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Rooms")
        }
    }
}

@Composable
fun CategoryItem(name: String, onClick: () -> Unit = {}) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .size(100.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.LightGray)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(name, fontSize = 14.sp)
        }
    }
}

@Composable
fun ItemRow(itemName: String, imageRes: Int) {
    Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = itemName,
            modifier = Modifier.size(50.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(itemName, fontSize = 16.sp, modifier = Modifier.padding(8.dp))
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    val navController = rememberNavController()
    val dummyViewModel = SharedInventoryViewModel()
    HomeScreen(
        onAddItemClick = {},
        onRoomClick = {},
        viewModel = dummyViewModel,
        navController = navController
    )
}


