package com.example.homeinventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.homeinventory.routes.Screen
import com.example.homeinventory.ui.screens.AddItemScreen
import com.example.homeinventory.ui.HomeScreen
import com.example.homeinventory.ui.ItemDetailScreen
import com.example.homeinventory.ui.RoomScreen
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.homeinventory.viewmodel.SharedInventoryViewModel
import com.example.homeinventory.ui.screens.InventoryScreen


import com.example.homeinventory.R

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HomeInventoryApp()
        }
    }
}

@Composable
fun HomeInventoryApp() {
    val navController = rememberNavController()
    val sharedViewModel: SharedInventoryViewModel = viewModel()
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = currentBackStackEntry?.destination?.route

    val screens = listOf(Screen.Home, Screen.AddItem, Screen.Rooms, Screen.ItemDetail)

    Scaffold(
        bottomBar = {
            NavigationBar {
                screens.forEach { screen ->
                    NavigationBarItem(
                        icon = {
                            when (screen) {
                                Screen.Home -> Icon(Icons.Default.Home, contentDescription = screen.title)
                                Screen.AddItem -> Icon(Icons.Default.List, contentDescription = screen.title)
                                Screen.Rooms -> Icon(
                                    painterResource(id = R.drawable.room),
                                    contentDescription = screen.title,
                                    modifier = Modifier.size(24.dp)
                                )
                                Screen.ItemDetail -> Icon(Icons.Default.Settings, contentDescription = screen.title)
                                Screen.Inventory -> Icon(Icons.Default.Info, contentDescription = screen.title)
                            }
                        },
                        label = { Text(screen.title) },
                        selected = currentDestination == screen.name,
                        onClick = {
                            // Only navigate if not already on the screen
                            if (currentDestination != screen.name) {
                                navController.navigate(screen.name) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.name,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.name) {
                HomeScreen(
                    navController = navController,
                    onAddItemClick = {
                        navController.navigate(Screen.AddItem.name) {
                            popUpTo(Screen.Home.name) {
                                inclusive = true // This clears everything up to (and including) Home
                            }
                            launchSingleTop = true
                        }
                    },
                    onRoomClick = {
                        navController.navigate(Screen.Rooms.name) {
                            popUpTo(Screen.Home.name) {
                                inclusive = true
                            }
                            launchSingleTop = true
                        }
                    },
                    viewModel = sharedViewModel
                )
            }
            composable(Screen.AddItem.name) {
                AddItemScreen(navController, viewModel = sharedViewModel)
            }
            composable(Screen.Rooms.name) {
                RoomScreen(onRoomSelected = { roomId ->
                    navController.navigate("${Screen.ItemDetail.name}/$roomId") {
                        popUpTo(Screen.ItemDetail.name) {
                            inclusive = false
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                })
            }
            composable("${Screen.ItemDetail.name}/{roomId}") { backStackEntry ->
                val roomId = backStackEntry.arguments?.getString("roomId") ?: ""
                ItemDetailScreen(roomId)
            }

            composable(Screen.Inventory.name) {
                InventoryScreen(viewModel = sharedViewModel)
            }

        }
    }
}
