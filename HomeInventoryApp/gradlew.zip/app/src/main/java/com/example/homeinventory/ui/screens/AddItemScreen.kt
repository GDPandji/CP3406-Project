@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.homeinventory.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.homeinventory.routes.Screen
import com.example.homeinventory.viewmodel.SharedInventoryViewModel

@Composable
fun AddItemScreen(
    navController: NavController,
    viewModel: SharedInventoryViewModel
) {
    // Collect state values from ViewModel
    val itemName by viewModel.itemName.collectAsState()
    val itemDescription by viewModel.itemDescription.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Add Item", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = itemName,
            onValueChange = { viewModel.updateItemName(it) },
            label = { Text("Item Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = itemDescription,
            onValueChange = { viewModel.updateItemDescription(it) },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                viewModel.addItem(itemName, itemDescription)
                navController.navigate(Screen.Home.name)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save")
        }
    }
}

