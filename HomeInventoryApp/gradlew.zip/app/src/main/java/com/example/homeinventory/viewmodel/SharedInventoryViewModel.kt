package com.example.homeinventory.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.homeinventory.data.AppDatabase
import com.example.homeinventory.model.Item
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SharedInventoryViewModel(application: Application) : AndroidViewModel(application) {

    private val itemDao = AppDatabase.getDatabase(application).itemDao()

    // Convert DAO Flow to StateFlow for Compose compatibility
    private val _allItems = itemDao.getAllItems()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allItems: StateFlow<List<Item>> = _allItems

    // UI State Variables
    private val _itemName = MutableStateFlow("")
    val itemName: StateFlow<String> = _itemName

    private val _itemDescription = MutableStateFlow("")
    val itemDescription: StateFlow<String> = _itemDescription

    private val _itemRoom = MutableStateFlow("")
    val itemRoom: StateFlow<String> = _itemRoom

    // Update State
    fun updateItemName(newName: String) {
        _itemName.value = newName
    }

    fun updateItemDescription(newDescription: String) {
        _itemDescription.value = newDescription
    }

    fun updateItemRoom(newRoom: String) {
        _itemRoom.value = newRoom
    }

    // Insert into database
    fun addItem(name: String, description: String, room: String) {
        viewModelScope.launch {
            itemDao.insert(Item(name = name, description = description, room = room))
            _itemName.value = ""
            _itemDescription.value = ""
            _itemRoom.value = ""
        }
    }
}
