@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.homeinventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun RoomScreen(onRoomSelected: (String) -> Unit) {
    // Example static room list
    Text("Room List (Tap a room to select)")
    // In a real app, each room item would call: onRoomSelected(roomId)
}

@Composable
fun RoomScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Room List", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Living Room")
        Text("Kitchen")
        Text("Bedroom")
    }
}

@Preview(showBackground = true)
@Composable
fun RoomScreenPreview() {
    RoomScreen()
}