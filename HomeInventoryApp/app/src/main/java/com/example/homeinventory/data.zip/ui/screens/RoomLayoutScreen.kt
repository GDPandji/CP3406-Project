@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.homeinventory.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.homeinventory.viewmodel.SharedInventoryViewModel
import kotlinx.coroutines.launch

@Composable
fun RoomLayoutScreen(
    roomId: Int,
    viewModel: SharedInventoryViewModel
) {
    val scope = rememberCoroutineScope()
    val allItems by viewModel.allItems.collectAsState()
    val itemsInRoom = allItems.filter { it.roomId == roomId }

    val placedItems = itemsInRoom.filter { it.gridX != null && it.gridY != null }
    val unplacedItems = itemsInRoom.filter { it.gridX == null || it.gridY == null }

    var selectedItemToPlace by remember { mutableStateOf<Int?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Room Layout", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        GridLayout(
            rows = 5,
            cols = 5,
            placedItems = placedItems,
            onCellClick = { x, y ->
                selectedItemToPlace?.let { itemId ->
                    scope.launch {
                        viewModel.updateItemPosition(itemId, x, y)
                        selectedItemToPlace = null
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
        Text("Unplaced Items", style = MaterialTheme.typography.titleMedium)

        LazyColumn {
            items(unplacedItems.size) { index ->
                val item = unplacedItems[index]
                ListItem(
                    headlineContent = { Text(item.name) },
                    leadingContent = { Text(item.icon ?: "📦") },
                    modifier = Modifier.clickable { selectedItemToPlace = item.id }
                )
            }
        }
    }
}

@Composable
fun GridLayout(
    rows: Int,
    cols: Int,
    placedItems: List<com.example.homeinventory.model.Item>,
    onCellClick: (x: Int, y: Int) -> Unit
) {
    Column {
        for (y in 0 until rows) {
            Row {
                for (x in 0 until cols) {
                    val item = placedItems.find { it.gridX == x && it.gridY == y }
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .padding(4.dp)
                            .background(Color.LightGray)
                            .clickable { onCellClick(x, y) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = item?.icon ?: "")
                    }
                }
            }
        }
    }
}
